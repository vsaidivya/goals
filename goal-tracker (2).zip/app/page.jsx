import GoalTracker from "../goal-tracker"

export default function Home() {
  return <GoalTracker />
}
