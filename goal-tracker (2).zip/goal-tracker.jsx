"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts"
import "./style.css"

// Mock Data
const mockUsers = [
  {
    id: "1",
    name: "Alex Johnson",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    role: "Product Manager",
  },
  {
    id: "2",
    name: "Sarah Williams",
    avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    role: "UX Designer",
  },
  {
    id: "3",
    name: "Michael Chen",
    avatar: "https://randomuser.me/api/portraits/men/22.jpg",
    role: "Developer",
  },
  {
    id: "4",
    name: "Emily Davis",
    avatar: "https://randomuser.me/api/portraits/women/67.jpg",
    role: "Marketing Specialist",
  },
  {
    id: "5",
    name: "James Wilson",
    avatar: "https://randomuser.me/api/portraits/men/91.jpg",
    role: "Data Analyst",
  },
]

// Update all due dates to be 5 days from now
const fiveDaysFromNow = new Date()
fiveDaysFromNow.setDate(fiveDaysFromNow.getDate() + 5)

const initialMockGoals = [
  {
    id: "1",
    title: "Launch New Website",
    description:
      "Complete the redesign and launch of our company website with improved UI/UX and mobile responsiveness.",
    progress: 50,
    createdBy: "1",
    createdAt: new Date("2023-04-15"),
    dueDate: new Date(fiveDaysFromNow),
    category: "Marketing",
    priority: "high",
    comments: [
      {
        id: "1",
        userId: "2",
        text: "The new design looks amazing! I think we should add more call-to-action buttons on the homepage.",
        timestamp: new Date("2023-05-10"),
      },
      {
        id: "2",
        userId: "3",
        text: "I've fixed the responsive issues on tablet devices. Please review when you have a chance.",
        timestamp: new Date("2023-05-15"),
      },
    ],
    milestones: [
      {
        id: "1",
        title: "Design Approval",
        completed: true,
        dueDate: new Date("2023-05-01"),
      },
      {
        id: "2",
        title: "Development Complete",
        completed: true,
        dueDate: new Date("2023-06-01"),
      },
      {
        id: "3",
        title: "Content Migration",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
      {
        id: "4",
        title: "Final Launch",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
    ],
    team: ["1", "2", "3", "4"],
  },
  {
    id: "2",
    title: "Increase User Engagement",
    description:
      "Implement strategies to increase user engagement by 30% in the next quarter through \n      Implement strategies to increase user engagement by 30% in the next quarter through improved features and content.",
    progress: 25,
    createdBy: "4",
    createdAt: new Date("2023-04-01"),
    dueDate: new Date(fiveDaysFromNow),
    category: "Product",
    priority: "medium",
    comments: [
      {
        id: "3",
        userId: "5",
        text: "Our analytics show that users spend more time on the platform when they receive personalized recommendations.",
        timestamp: new Date("2023-04-20"),
      },
    ],
    milestones: [
      {
        id: "5",
        title: "User Research",
        completed: true,
        dueDate: new Date("2023-04-15"),
      },
      {
        id: "6",
        title: "Feature Prioritization",
        completed: true,
        dueDate: new Date("2023-05-01"),
      },
      {
        id: "7",
        title: "Implementation",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
      {
        id: "8",
        title: "Measurement & Analysis",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
    ],
    team: ["1", "4", "5"],
  },
  {
    id: "3",
    title: "Optimize Conversion Funnel",
    description: "Analyze and optimize the conversion funnel to improve conversion rates by 20%.",
    progress: 25,
    createdBy: "5",
    createdAt: new Date("2023-05-01"),
    dueDate: new Date(fiveDaysFromNow),
    category: "Sales",
    priority: "high",
    comments: [
      {
        id: "4",
        userId: "1",
        text: "We should focus on reducing friction in the checkout process first.",
        timestamp: new Date("2023-05-05"),
      },
      {
        id: "5",
        userId: "4",
        text: "I've prepared a detailed analysis of drop-off points in our funnel. Let's discuss in our next meeting.",
        timestamp: new Date("2023-05-12"),
      },
    ],
    milestones: [
      {
        id: "9",
        title: "Funnel Analysis",
        completed: true,
        dueDate: new Date("2023-05-15"),
      },
      {
        id: "10",
        title: "Hypothesis Development",
        completed: true,
        dueDate: new Date("2023-06-01"),
      },
      {
        id: "11",
        title: "A/B Testing",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
      {
        id: "12",
        title: "Implementation of Changes",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
    ],
    team: ["1", "4", "5"],
  },
  {
    id: "4",
    title: "Develop Mobile App",
    description: "Create a native mobile application for iOS and Android to extend our platform reach.",
    progress: 25,
    createdBy: "3",
    createdAt: new Date("2023-05-10"),
    dueDate: new Date(fiveDaysFromNow),
    category: "Development",
    priority: "medium",
    comments: [
      {
        id: "6",
        userId: "2",
        text: "I've completed the initial wireframes for the app. Would love your feedback!",
        timestamp: new Date("2023-05-20"),
      },
    ],
    milestones: [
      {
        id: "13",
        title: "Requirements Gathering",
        completed: true,
        dueDate: new Date("2023-06-01"),
      },
      {
        id: "14",
        title: "Design Phase",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
      {
        id: "15",
        title: "Development",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
      {
        id: "16",
        title: "Testing & Launch",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
    ],
    team: ["1", "2", "3"],
  },
  {
    id: "5",
    title: "Customer Satisfaction Survey",
    description: "Conduct a comprehensive customer satisfaction survey to identify areas for improvement.",
    progress: 75,
    createdBy: "4",
    createdAt: new Date("2023-03-15"),
    dueDate: new Date(fiveDaysFromNow),
    category: "Customer Success",
    priority: "low",
    comments: [
      {
        id: "7",
        userId: "1",
        text: "We've received over 500 responses so far. The initial results look promising!",
        timestamp: new Date("2023-04-20"),
      },
      {
        id: "8",
        userId: "5",
        text: "I've started analyzing the data. There are some interesting patterns emerging.",
        timestamp: new Date("2023-05-10"),
      },
    ],
    milestones: [
      {
        id: "17",
        title: "Survey Design",
        completed: true,
        dueDate: new Date("2023-03-31"),
      },
      {
        id: "18",
        title: "Survey Distribution",
        completed: true,
        dueDate: new Date("2023-04-15"),
      },
      {
        id: "19",
        title: "Data Collection",
        completed: true,
        dueDate: new Date("2023-05-15"),
      },
      {
        id: "20",
        title: "Analysis & Reporting",
        completed: false,
        dueDate: new Date(fiveDaysFromNow),
      },
    ],
    team: ["1", "4", "5"],
  },
]

// Helper functions
const getUserById = (id) => {
  return mockUsers.find((user) => user.id === id)
}

const formatDate = (date) => {
  // Check if date is valid
  if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
    return "Invalid date"
  }

  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date)
}

const calculateProgress = (milestones) => {
  if (!milestones || milestones.length === 0) return 0
  const completedCount = milestones.filter((m) => m.completed).length
  return Math.round((completedCount / milestones.length) * 100)
}

const calculateDaysLeft = (dueDate) => {
  if (!dueDate || !(dueDate instanceof Date) || isNaN(dueDate.getTime())) {
    return 0
  }

  const today = new Date()
  const diffTime = dueDate.getTime() - today.getTime()
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
}

const getProgressColor = (progress) => {
  if (progress < 30) return "#f87171"
  if (progress < 70) return "#facc15"
  return "#4ade80"
}

const getPriorityColor = (priority) => {
  switch (priority) {
    case "high":
      return "#ef4444"
    case "medium":
      return "#f59e0b"
    case "low":
      return "#3b82f6"
    default:
      return "#9ca3af"
  }
}

// Helper functions for localStorage
const saveGoalsToLocalStorage = (goals) => {
  try {
    const serializedGoals = JSON.stringify(goals, (key, value) => {
      if (value instanceof Date) {
        return { type: "date", value: value.toISOString() }
      }
      return value
    })
    localStorage.setItem("goals", serializedGoals)
  } catch (error) {
    console.error("Error saving goals to localStorage:", error)
  }
}

const loadGoalsFromLocalStorage = () => {
  try {
    const serializedGoals = localStorage.getItem("goals")
    if (!serializedGoals) return null

    return JSON.parse(serializedGoals, (key, value) => {
      if (value && typeof value === "object" && value.type === "date") {
        return new Date(value.value)
      }
      return value
    })
  } catch (error) {
    console.error("Error loading goals from localStorage:", error)
    return null
  }
}

// Main Component
const GoalTracker = () => {
  const [goals, setGoals] = useState([])
  const [selectedGoal, setSelectedGoal] = useState(null)
  const [showAddGoalModal, setShowAddGoalModal] = useState(false)
  const [showGoalDetailModal, setShowGoalDetailModal] = useState(false)
  const [newComment, setNewComment] = useState("")
  const [newGoal, setNewGoal] = useState({
    title: "",
    description: "",
    category: "",
    priority: "medium",
    dueDate: new Date(),
    team: [],
  })
  const [filter, setFilter] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [currentUser] = useState(mockUsers[0])
  const [selectedTeamMembers, setSelectedTeamMembers] = useState([])
  const [newMilestone, setNewMilestone] = useState("")
  const [activeTab, setActiveTab] = useState("overview")
  const [formErrors, setFormErrors] = useState({})

  // Load goals from localStorage on component mount
  useEffect(() => {
    const savedGoals = loadGoalsFromLocalStorage()
    if (savedGoals && savedGoals.length > 0) {
      // Ensure all date objects are properly reconstructed
      const processedGoals = savedGoals.map((goal) => {
        const processedMilestones = goal.milestones.map((milestone) => ({
          ...milestone,
          dueDate: milestone.dueDate instanceof Date ? milestone.dueDate : new Date(milestone.dueDate),
        }))

        return {
          ...goal,
          createdAt: goal.createdAt instanceof Date ? goal.createdAt : new Date(goal.createdAt),
          dueDate: goal.dueDate instanceof Date ? goal.dueDate : new Date(goal.dueDate),
          comments: goal.comments.map((comment) => ({
            ...comment,
            timestamp: comment.timestamp instanceof Date ? comment.timestamp : new Date(comment.timestamp),
          })),
          milestones: processedMilestones,
          // Recalculate progress based on milestones
          progress: calculateProgress(processedMilestones),
        }
      })
      setGoals(processedGoals)
    } else {
      // Update initial mock goals to have correct progress
      const updatedMockGoals = initialMockGoals.map((goal) => ({
        ...goal,
        progress: calculateProgress(goal.milestones),
      }))
      setGoals(updatedMockGoals)
    }
  }, [])

  // Save goals to localStorage whenever they change
  useEffect(() => {
    if (goals.length > 0) {
      saveGoalsToLocalStorage(goals)
    }
  }, [goals])

  // Filter goals based on category and search term
  const filteredGoals = goals.filter((goal) => {
    const matchesFilter = filter === "all" || goal.category.toLowerCase() === filter.toLowerCase()
    const matchesSearch =
      goal.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      goal.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesFilter && matchesSearch
  })

  // Chart data
  const categoryData = goals.reduce((acc, goal) => {
    const existingCategory = acc.find((item) => item.name === goal.category)
    if (existingCategory) {
      existingCategory.value += 1
    } else {
      acc.push({ name: goal.category, value: 1 })
    }
    return acc
  }, [])

  const progressData = [
    { name: "Completed", value: goals.filter((goal) => goal.progress === 100).length },
    { name: "In Progress", value: goals.filter((goal) => goal.progress > 0 && goal.progress < 100).length },
    { name: "Not Started", value: goals.filter((goal) => goal.progress === 0).length },
  ]

  const COLORS = ["#4ade80", "#facc15", "#f87171"]

  const priorityData = [
    { name: "High", count: goals.filter((goal) => goal.priority === "high").length },
    { name: "Medium", count: goals.filter((goal) => goal.priority === "medium").length },
    { name: "Low", count: goals.filter((goal) => goal.priority === "low").length },
  ]

  // Handle adding a new comment
  const handleAddComment = () => {
    if (!newComment.trim() || !selectedGoal) return

    const updatedGoal = {
      ...selectedGoal,
      comments: [
        ...selectedGoal.comments,
        {
          id: Date.now().toString(),
          userId: currentUser.id,
          text: newComment,
          timestamp: new Date(),
        },
      ],
    }

    setGoals(goals.map((goal) => (goal.id === selectedGoal.id ? updatedGoal : goal)))
    setSelectedGoal(updatedGoal)
    setNewComment("")
  }

  // Handle adding a new milestone
  const handleAddMilestone = () => {
    if (!newMilestone.trim() || !selectedGoal) return

    const updatedMilestones = [
      ...selectedGoal.milestones,
      {
        id: Date.now().toString(),
        title: newMilestone,
        completed: false,
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Default due date: 1 week from now
      },
    ]

    const completedCount = updatedMilestones.filter((m) => m.completed).length
    const totalCount = updatedMilestones.length

    const updatedGoal = {
      ...selectedGoal,
      milestones: updatedMilestones,
      progress: Math.round((completedCount / totalCount) * 100),
    }

    setGoals(goals.map((goal) => (goal.id === selectedGoal.id ? updatedGoal : goal)))
    setSelectedGoal(updatedGoal)
    setNewMilestone("")
  }

  // Handle toggling milestone completion
  const handleToggleMilestone = (milestoneId) => {
    if (!selectedGoal) return

    const updatedMilestones = selectedGoal.milestones.map((milestone) =>
      milestone.id === milestoneId ? { ...milestone, completed: !milestone.completed } : milestone,
    )

    const completedCount = updatedMilestones.filter((m) => m.completed).length
    const totalCount = updatedMilestones.length

    const updatedGoal = {
      ...selectedGoal,
      milestones: updatedMilestones,
      progress: totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0,
    }

    setGoals(goals.map((goal) => (goal.id === selectedGoal.id ? updatedGoal : goal)))
    setSelectedGoal(updatedGoal)
  }

  // Validate form
  const validateForm = () => {
    const errors = {}

    if (!newGoal.title.trim()) {
      errors.title = "Title is required"
    }

    if (!newGoal.description.trim()) {
      errors.description = "Description is required"
    }

    if (!newGoal.category) {
      errors.category = "Category is required"
    }

    if (!newGoal.dueDate || !(newGoal.dueDate instanceof Date) || isNaN(newGoal.dueDate.getTime())) {
      errors.dueDate = "Valid due date is required"
    }

    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  // Handle adding a new goal
  const handleAddGoal = () => {
    if (!validateForm()) return

    const newGoalObj = {
      id: Date.now().toString(),
      title: newGoal.title,
      description: newGoal.description,
      progress: 0, // Will be 0 since there are no milestones yet
      createdBy: currentUser.id,
      createdAt: new Date(),
      dueDate: newGoal.dueDate,
      category: newGoal.category,
      priority: newGoal.priority,
      comments: [],
      milestones: [],
      team: selectedTeamMembers,
    }

    setGoals([...goals, newGoalObj])
    setShowAddGoalModal(false)
    setNewGoal({
      title: "",
      description: "",
      category: "",
      priority: "medium",
      dueDate: new Date(),
      team: [],
    })
    setSelectedTeamMembers([])
    setFormErrors({})
  }

  // Handle opening goal detail modal
  const handleOpenGoalDetail = (goal) => {
    setSelectedGoal(goal)
    setShowGoalDetailModal(true)
  }

  // Handle team member selection
  const handleTeamMemberToggle = (userId) => {
    if (selectedTeamMembers.includes(userId)) {
      setSelectedTeamMembers(selectedTeamMembers.filter((id) => id !== userId))
    } else {
      setSelectedTeamMembers([...selectedTeamMembers, userId])
    }
  }

  // Handle date change for new goal
  const handleDateChange = (e) => {
    const dateValue = e.target.value
    if (dateValue) {
      setNewGoal({
        ...newGoal,
        dueDate: new Date(dateValue),
      })
    }
  }

  // Get today's date in YYYY-MM-DD format for the date input
  const getTodayFormatted = () => {
    const today = new Date()
    return today.toISOString().split("T")[0]
  }

  function handleDueDateChange(e) {
    if (!selectedGoal) return

    const newDueDate = new Date(e.target.value)
    if (!isNaN(newDueDate.getTime())) {
      const updatedGoal = {
        ...selectedGoal,
        dueDate: newDueDate,
      }

      setGoals(goals.map((goal) => (goal.id === selectedGoal.id ? updatedGoal : goal)))
      setSelectedGoal(updatedGoal)
    }
  }

  useEffect(() => {
    if (showGoalDetailModal || showAddGoalModal) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "auto"
    }

    return () => {
      document.body.style.overflow = "auto"
    }
  }, [showGoalDetailModal, showAddGoalModal])

  // Function to handle opening goal in a new tab
  function handleOpenInNewTab(e, goal) {
    e.stopPropagation() // Prevent the card click event from firing

    // Create a temporary storage for the selected goal
    localStorage.setItem(
      "tempSelectedGoal",
      JSON.stringify(goal, (key, value) => {
        if (value instanceof Date) {
          return { type: "date", value: value.toISOString() }
        }
        return value
      }),
    )

    // Open a new tab with a URL parameter indicating to open the goal
    const url = new URL(window.location.href)
    url.searchParams.set("goalId", goal.id)
    window.open(url.toString(), "_blank")
  }

  // Check for URL parameters on component mount to see if we should open a goal
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const goalId = urlParams.get("goalId")

    if (goalId) {
      // Try to get the goal from localStorage
      const tempGoalJson = localStorage.getItem("tempSelectedGoal")
      if (tempGoalJson) {
        try {
          const tempGoal = JSON.parse(tempGoalJson, (key, value) => {
            if (value && typeof value === "object" && value.type === "date") {
              return new Date(value.value)
            }
            return value
          })

          // If the IDs match, open the goal detail modal
          if (tempGoal.id === goalId) {
            setSelectedGoal(tempGoal)
            setShowGoalDetailModal(true)
            // Clean up the temporary storage
            localStorage.removeItem("tempSelectedGoal")
          } else {
            // If IDs don't match, try to find the goal in our goals array
            const foundGoal = goals.find((g) => g.id === goalId)
            if (foundGoal) {
              setSelectedGoal(foundGoal)
              setShowGoalDetailModal(true)
            }
          }
        } catch (error) {
          console.error("Error parsing temporary goal:", error)
        }
      } else {
        // If no temp goal in localStorage, try to find it in the goals array
        const foundGoal = goals.find((g) => g.id === goalId)
        if (foundGoal) {
          setSelectedGoal(foundGoal)
          setShowGoalDetailModal(true)
        }
      }
    }
  }, [goals])

  return (
    <div className="goal-tracker">
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-logo">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 2L2 7L12 12L22 7L12 2Z"
                stroke="#4F46E5"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M2 17L12 22L22 17"
                stroke="#4F46E5"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M2 12L12 17L22 12"
                stroke="#4F46E5"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </motion.div>
          <h1>GoalTracker</h1>
        </div>
        <div className="navbar-search">
          <input
            type="text"
            placeholder="Search goals..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="navbar-profile">
          <div className="notifications">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
              />
            </svg>
            <span className="badge">3</span>
          </div>
          <div className="profile">
            <img src={currentUser.avatar || "/placeholder.svg"} alt={currentUser.name} />
            <span>{currentUser.name}</span>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="main-content">
        <div className="dashboard-header">
          <div>
            <h2>Goal Dashboard</h2>
            <p>Track and manage your personal and team goals</p>
          </div>
          <motion.button
            className="add-goal-btn"
            onClick={() => setShowAddGoalModal(true)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              width="20"
              height="20"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Add New Goal
          </motion.button>
        </div>

        <div className="dashboard-stats">
          <motion.div
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="stat-icon" style={{ backgroundColor: "rgba(79, 70, 229, 0.1)" }}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="#4F46E5">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                />
              </svg>
            </div>
            <div className="stat-content">
              <h3>Total Goals</h3>
              <p>{goals.length}</p>
            </div>
          </motion.div>

          <motion.div
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="stat-icon" style={{ backgroundColor: "rgba(16, 185, 129, 0.1)" }}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="#10B981">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div className="stat-content">
              <h3>Completed</h3>
              <p>{goals.filter((goal) => goal.progress === 100).length}</p>
            </div>
          </motion.div>

          <motion.div
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="stat-icon" style={{ backgroundColor: "rgba(245, 158, 11, 0.1)" }}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="#F59E0B">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div className="stat-content">
              <h3>In Progress</h3>
              <p>{goals.filter((goal) => goal.progress > 0 && goal.progress < 100).length}</p>
            </div>
          </motion.div>

          <motion.div
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div className="stat-icon" style={{ backgroundColor: "rgba(239, 68, 68, 0.1)" }}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="#EF4444">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                />
              </svg>
            </div>
            <div className="stat-content">
              <h3>High Priority</h3>
              <p>{goals.filter((goal) => goal.priority === "high").length}</p>
            </div>
          </motion.div>
        </div>

        <div className="dashboard-charts">
          <div className="chart-container">
            <h3>Goals by Category</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-container">
            <h3>Goals by Status</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={priorityData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#4F46E5" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="filter-container">
          <div className="filter-buttons">
            <button className={filter === "all" ? "active" : ""} onClick={() => setFilter("all")}>
              All
            </button>
            <button className={filter === "Marketing" ? "active" : ""} onClick={() => setFilter("Marketing")}>
              Marketing
            </button>
            <button className={filter === "Product" ? "active" : ""} onClick={() => setFilter("Product")}>
              Product
            </button>
            <button className={filter === "Development" ? "active" : ""} onClick={() => setFilter("Development")}>
              Development
            </button>
            <button className={filter === "Sales" ? "active" : ""} onClick={() => setFilter("Sales")}>
              Sales
            </button>
            <button
              className={filter === "Customer Success" ? "active" : ""}
              onClick={() => setFilter("Customer Success")}
            >
              Customer Success
            </button>
          </div>
        </div>

        <div className="goals-container">
          {filteredGoals.length === 0 ? (
            <div className="no-goals">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              <p>No goals found. Try adjusting your filters or create a new goal.</p>
            </div>
          ) : (
            <div className="goals-grid">
              {filteredGoals.map((goal) => (
                <motion.div
                  key={goal.id}
                  className="goal-card"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3 }}
                  whileHover={{ y: -5, boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)" }}
                  onClick={() => handleOpenGoalDetail(goal)}
                >
                  <div className="goal-card-header">
                    <div className="goal-category" style={{ backgroundColor: getPriorityColor(goal.priority) }}>
                      {goal.category}
                    </div>
                    <div className="goal-actions">
                      <div className="goal-priority" style={{ color: getPriorityColor(goal.priority) }}>
                        {goal.priority.charAt(0).toUpperCase() + goal.priority.slice(1)} Priority
                      </div>
                      <button
                        className="open-new-tab-btn"
                        onClick={(e) => handleOpenInNewTab(e, goal)}
                        title="Open in new tab"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          width="16"
                          height="16"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <h3>{goal.title}</h3>
                  <p className="goal-description">{goal.description}</p>
                  <div className="goal-progress">
                    <div className="progress-text">
                      <span>Progress</span>
                      <span>{goal.progress}%</span>
                    </div>
                    <div className="progress-bar">
                      <div
                        className="progress-fill"
                        style={{
                          width: `${goal.progress}%`,
                          backgroundColor: getProgressColor(goal.progress),
                        }}
                      ></div>
                    </div>
                  </div>
                  <div className="goal-footer">
                    <div className="goal-due-date">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                      <span>Due: {formatDate(goal.dueDate)}</span>
                    </div>
                    <div className="goal-team">
                      {goal.team.slice(0, 3).map((userId) => {
                        const user = getUserById(userId)
                        return user ? (
                          <img key={userId} src={user.avatar || "/placeholder.svg"} alt={user.name} title={user.name} />
                        ) : null
                      })}
                      {goal.team.length > 3 && <div className="team-more">+{goal.team.length - 3}</div>}
                    </div>
                  </div>
                  <div className="goal-milestones">
                    <div className="milestone-count">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                        />
                      </svg>
                      <span>
                        {goal.milestones.filter((m) => m.completed).length}/{goal.milestones.length} milestones
                      </span>
                    </div>
                    <div className="comment-count">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                        />
                      </svg>
                      <span>{goal.comments.length} comments</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <p>&copy; {new Date().getFullYear()} GoalTracker. All rights reserved.</p>
          <div className="footer-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Contact Us</a>
          </div>
        </div>
      </footer>

      {/* Add Goal Modal */}
      <AnimatePresence>
        {showAddGoalModal && (
          <motion.div
            className="modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="modal"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 25 }}
            >
              <div className="modal-header">
                <h2>Create New Goal</h2>
                <button className="close-btn" onClick={() => setShowAddGoalModal(false)}>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="modal-body">
                <div className="form-group">
                  <label htmlFor="goal-title">Goal Title</label>
                  <input
                    type="text"
                    id="goal-title"
                    placeholder="Enter goal title"
                    value={newGoal.title}
                    onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                    className={formErrors.title ? "error" : ""}
                  />
                  {formErrors.title && <div className="error-message">{formErrors.title}</div>}
                </div>
                <div className="form-group">
                  <label htmlFor="goal-description">Description</label>
                  <textarea
                    id="goal-description"
                    placeholder="Enter goal description"
                    value={newGoal.description}
                    onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                    className={formErrors.description ? "error" : ""}
                  ></textarea>
                  {formErrors.description && <div className="error-message">{formErrors.description}</div>}
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="goal-category">Category</label>
                    <select
                      id="goal-category"
                      value={newGoal.category}
                      onChange={(e) => setNewGoal({ ...newGoal, category: e.target.value })}
                      className={formErrors.category ? "error" : ""}
                    >
                      <option value="">Select a category</option>
                      <option value="Marketing">Marketing</option>
                      <option value="Product">Product</option>
                      <option value="Development">Development</option>
                      <option value="Sales">Sales</option>
                      <option value="Customer Success">Customer Success</option>
                    </select>
                    {formErrors.category && <div className="error-message">{formErrors.category}</div>}
                  </div>
                  <div className="form-group">
                    <label htmlFor="goal-priority">Priority</label>
                    <select
                      id="goal-priority"
                      value={newGoal.priority}
                      onChange={(e) => setNewGoal({ ...newGoal, priority: e.target.value })}
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label htmlFor="goal-due-date">Due Date</label>
                  <input
                    type="date"
                    id="goal-due-date"
                    min={getTodayFormatted()}
                    value={
                      newGoal.dueDate instanceof Date && !isNaN(newGoal.dueDate.getTime())
                        ? newGoal.dueDate.toISOString().split("T")[0]
                        : getTodayFormatted()
                    }
                    onChange={handleDateChange}
                    className={formErrors.dueDate ? "error" : ""}
                  />
                  {formErrors.dueDate && <div className="error-message">{formErrors.dueDate}</div>}
                </div>
                <div className="form-group">
                  <label>Team Members</label>
                  <div className="team-selection">
                    {mockUsers.map((user) => (
                      <div
                        key={user.id}
                        className={`team-member ${selectedTeamMembers.includes(user.id) ? "selected" : ""}`}
                        onClick={() => handleTeamMemberToggle(user.id)}
                      >
                        <img src={user.avatar || "/placeholder.svg"} alt={user.name} />
                        <span>{user.name}</span>
                        {selectedTeamMembers.includes(user.id) && (
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button className="cancel-btn" onClick={() => setShowAddGoalModal(false)}>
                  Cancel
                </button>
                <button className="create-btn" onClick={handleAddGoal}>
                  Create Goal
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Goal Detail Modal */}
      <AnimatePresence>
        {showGoalDetailModal && selectedGoal && (
          <motion.div
            className="modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="modal goal-detail-modal"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 25 }}
            >
              <div className="modal-header">
                <div>
                  <div className="goal-category" style={{ backgroundColor: getPriorityColor(selectedGoal.priority) }}>
                    {selectedGoal.category}
                  </div>
                  <h2>{selectedGoal.title}</h2>
                </div>
                <button className="close-btn" onClick={() => setShowGoalDetailModal(false)}>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="goal-detail-tabs">
                <button className={activeTab === "overview" ? "active" : ""} onClick={() => setActiveTab("overview")}>
                  Overview
                </button>
                <button
                  className={activeTab === "milestones" ? "active" : ""}
                  onClick={() => setActiveTab("milestones")}
                >
                  Milestones
                </button>
                <button className={activeTab === "comments" ? "active" : ""} onClick={() => setActiveTab("comments")}>
                  Comments
                </button>
                <button className={activeTab === "team" ? "active" : ""} onClick={() => setActiveTab("team")}>
                  Team
                </button>
              </div>

              <div className="modal-body">
                {activeTab === "overview" && (
                  <div className="goal-overview">
                    <div className="goal-info">
                      <p className="goal-description">{selectedGoal.description}</p>

                      <div className="goal-meta">
                        <div className="meta-item">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                            />
                          </svg>
                          <div>
                            <span>Created</span>
                            <p>{formatDate(selectedGoal.createdAt)}</p>
                          </div>
                        </div>

                        <div className="meta-item">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                            />
                          </svg>
                          <div>
                            <span>Due Date</span>
                            <input
                              type="date"
                              value={
                                selectedGoal.dueDate instanceof Date && !isNaN(selectedGoal.dueDate.getTime())
                                  ? selectedGoal.dueDate.toISOString().split("T")[0]
                                  : ""
                              }
                              onChange={handleDueDateChange}
                              style={{
                                border: "1px solid #ddd",
                                borderRadius: "4px",
                                padding: "4px 8px",
                                fontSize: "14px",
                                marginTop: "4px",
                              }}
                            />
                          </div>
                        </div>

                        <div className="meta-item">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                          </svg>
                          <div>
                            <span>Time Left</span>
                            <p>{calculateDaysLeft(selectedGoal.dueDate)} days</p>
                          </div>
                        </div>

                        <div className="meta-item">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                            />
                          </svg>
                          <div>
                            <span>Priority</span>
                            <p style={{ color: getPriorityColor(selectedGoal.priority) }}>
                              {selectedGoal.priority.charAt(0).toUpperCase() + selectedGoal.priority.slice(1)}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="goal-progress">
                        <div className="progress-text">
                          <span>Overall Progress</span>
                          <span>{selectedGoal.progress}%</span>
                        </div>
                        <div className="progress-bar">
                          <div
                            className="progress-fill"
                            style={{
                              width: `${selectedGoal.progress}%`,
                              backgroundColor: getProgressColor(selectedGoal.progress),
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    <div className="goal-summary">
                      <div className="summary-item">
                        <h4>Milestones</h4>
                        <div className="summary-content">
                          <div className="milestone-summary">
                            <div className="milestone-progress">
                              <svg viewBox="0 0 36 36">
                                <path
                                  d="M18 2.0845
                                    a 15.9155 15.9155 0 0 1 0 31.831
                                    a 15.9155 15.9155 0 0 1 0 -31.831"
                                  fill="none"
                                  stroke="#eee"
                                  strokeWidth="3"
                                />
                                <path
                                  d="M18 2.0845
                                    a 15.9155 15.9155 0 0 1 0 31.831
                                    a 15.9155 15.9155 0 0 1 0 -31.831"
                                  fill="none"
                                  stroke={getProgressColor(selectedGoal.progress)}
                                  strokeWidth="3"
                                  strokeDasharray={`${selectedGoal.progress}, 100`}
                                />
                              </svg>
                              <div className="milestone-count">
                                <span>{selectedGoal.milestones.filter((m) => m.completed).length}</span>
                                <span>/{selectedGoal.milestones.length}</span>
                              </div>
                            </div>
                            <div>
                              <p>Completed</p>
                              <p className="milestone-percent">
                                {selectedGoal.milestones.length > 0
                                  ? Math.round(
                                      (selectedGoal.milestones.filter((m) => m.completed).length /
                                        selectedGoal.milestones.length) *
                                        100,
                                    )
                                  : 0}
                                %
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="summary-item">
                        <h4>Team</h4>
                        <div className="summary-content">
                          <div className="team-summary">
                            {selectedGoal.team.map((userId) => {
                              const user = getUserById(userId)
                              return user ? (
                                <div key={userId} className="team-member-summary">
                                  <img src={user.avatar || "/placeholder.svg"} alt={user.name} />
                                  <div>
                                    <p>{user.name}</p>
                                    <span>{user.role}</span>
                                  </div>
                                </div>
                              ) : null
                            })}
                          </div>
                        </div>
                      </div>

                      <div className="summary-item">
                        <h4>Recent Activity</h4>
                        <div className="summary-content">
                          <div className="activity-summary">
                            {selectedGoal.comments.slice(-2).map((comment) => {
                              const user = getUserById(comment.userId)
                              return user ? (
                                <div key={comment.id} className="activity-item">
                                  <img src={user.avatar || "/placeholder.svg"} alt={user.name} />
                                  <div>
                                    <p>
                                      <strong>{user.name}</strong> commented
                                    </p>
                                    <span>{new Date(comment.timestamp).toLocaleDateString()}</span>
                                  </div>
                                </div>
                              ) : null
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "milestones" && (
                  <div className="goal-milestones-tab">
                    <div className="add-milestone">
                      <input
                        type="text"
                        placeholder="Add a new milestone..."
                        value={newMilestone}
                        onChange={(e) => setNewMilestone(e.target.value)}
                      />
                      <button onClick={handleAddMilestone}>Add</button>
                    </div>

                    <div className="milestones-list">
                      {selectedGoal.milestones.map((milestone) => (
                        <div key={milestone.id} className="milestone-item">
                          <div
                            className={`milestone-checkbox ${milestone.completed ? "completed" : ""}`}
                            onClick={() => handleToggleMilestone(milestone.id)}
                          >
                            {milestone.completed && (
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                          <div className="milestone-content">
                            <h4 className={milestone.completed ? "completed" : ""}>{milestone.title}</h4>
                            <p>Due: {formatDate(milestone.dueDate)}</p>
                          </div>
                          <div
                            className="milestone-badge"
                            style={{ backgroundColor: milestone.completed ? "#4ade80" : "#f87171" }}
                          >
                            {milestone.completed ? "Completed" : "Pending"}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === "comments" && (
                  <div className="goal-comments">
                    <div className="comments-list">
                      {selectedGoal.comments.length === 0 ? (
                        <div className="no-comments">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                            />
                          </svg>
                          <p>No comments yet. Be the first to comment!</p>
                        </div>
                      ) : (
                        selectedGoal.comments.map((comment) => {
                          const user = getUserById(comment.userId)
                          return user ? (
                            <div key={comment.id} className="comment-item">
                              <div className="comment-avatar">
                                <img src={user.avatar || "/placeholder.svg"} alt={user.name} />
                              </div>
                              <div className="comment-content">
                                <div className="comment-header">
                                  <h4>{user.name}</h4>
                                  <span>
                                    {new Date(comment.timestamp).toLocaleDateString()} at{" "}
                                    {new Date(comment.timestamp).toLocaleTimeString([], {
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}
                                  </span>
                                </div>
                                <p>{comment.text}</p>
                              </div>
                            </div>
                          ) : null
                        })
                      )}
                    </div>

                    <div className="add-comment">
                      <div className="comment-avatar">
                        <img src={currentUser.avatar || "/placeholder.svg"} alt={currentUser.name} />
                      </div>
                      <div className="comment-input">
                        <textarea
                          placeholder="Add a comment..."
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                        ></textarea>
                        <button onClick={handleAddComment}>Post</button>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "team" && (
                  <div className="goal-team-tab">
                    <div className="team-members-list">
                      {selectedGoal.team.map((userId) => {
                        const user = getUserById(userId)
                        return user ? (
                          <div key={userId} className="team-member-card">
                            <img src={user.avatar || "/placeholder.svg"} alt={user.name} />
                            <h4>{user.name}</h4>
                            <p>{user.role}</p>
                          </div>
                        ) : null
                      })}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default GoalTracker
